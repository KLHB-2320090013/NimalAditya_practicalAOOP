public class OrderStep {
    private String stepName;

    public OrderStep(String stepName) {
        this.stepName = stepName;
    }

    public void execute(Order order) {
        System.out.println("Executing " + stepName + " for " + order);
        order.setStatus(stepName + " completed");
    }
}
