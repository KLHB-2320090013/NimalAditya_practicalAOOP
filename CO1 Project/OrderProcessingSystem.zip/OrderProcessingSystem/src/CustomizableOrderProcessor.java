import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CustomizableOrderProcessor extends OrderProcessor {
    private Map<String, List<OrderStep>> customSteps;

    public CustomizableOrderProcessor() {
        super(new ArrayList<>());
        customSteps = new HashMap<>();
    }

    public void addStep(String orderType, OrderStep step) {
        customSteps.computeIfAbsent(orderType, k -> new ArrayList<>()).add(step);
    }

    @Override
    public void processOrder(Order order) {
        List<OrderStep> steps = customSteps.getOrDefault(order.getOrderType(), new ArrayList<>());
        for (OrderStep step : steps) {
            step.execute(order);
        }
    }
}
