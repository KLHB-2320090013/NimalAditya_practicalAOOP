import java.util.List;

public class OrderProcessor {
    private List<OrderStep> steps;

    public OrderProcessor(List<OrderStep> steps) {
        this.steps = steps;
    }

    public void processOrder(Order order) {
        for (OrderStep step : steps) {
            step.execute(order);
        }
    }
}
