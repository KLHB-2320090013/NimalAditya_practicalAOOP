public class Order {
    private int orderId;
    private String customerName;
    private String orderType;
    private String status;

    public Order(int orderId, String customerName, String orderType) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.orderType = orderType;
        this.status = "Pending";
    }

    public int getOrderId() {
        return orderId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getOrderType() {
        return orderType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Order{id=" + orderId + ", customer=" + customerName + ", type=" + orderType + ", status=" + status + "}";
    }
}
