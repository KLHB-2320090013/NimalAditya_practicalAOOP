import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        // Define steps
        OrderStep validationStep = new OrderStep("Validation");
        OrderStep paymentStep = new OrderStep("Payment");
        OrderStep shippingStep = new OrderStep("Shipping");

        // Create order processors
        OrderProcessor standardProcessor = new OrderProcessor(Arrays.asList(validationStep, paymentStep, shippingStep));

        CustomizableOrderProcessor customProcessor = new CustomizableOrderProcessor();
        customProcessor.addStep("Standard", validationStep);
        customProcessor.addStep("Standard", paymentStep);
        customProcessor.addStep("Express", validationStep);
        customProcessor.addStep("Express", shippingStep);

        // Create orders
        Order order1 = new Order(1, "Alice", "Standard");
        Order order2 = new Order(2, "Bob", "Express");

        // Process orders
        System.out.println(order1);
        standardProcessor.processOrder(order1);
        System.out.println(order1);

        System.out.println(order2);
        customProcessor.processOrder(order2);
        System.out.println(order2);
    }
}
